// content.js
console.log('content.js activated');