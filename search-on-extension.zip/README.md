# search-on-extention
Allows user to highlight content on a page and search for that content via convienent context menu item (right click).

To install locally:
1. Unzip files.
2. In chrome, navigate to chrome://extensions
3. Turn on `Developer mode`.
4. Click `Load upacked`.
5. Select the unzipped folder.


This video has a walkthrough of the process as well: https://developer.chrome.com/extensions/getstarted